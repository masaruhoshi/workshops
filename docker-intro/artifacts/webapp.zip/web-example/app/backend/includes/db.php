<?php 
$DB_HOST = getenv("DB_HOST");
$DB_USER = getenv("DB_USERNAME");
$DB_PASS = getenv("DB_PASSWORD");
$DB_NAME = getenv("DB_DATABASE");
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>
