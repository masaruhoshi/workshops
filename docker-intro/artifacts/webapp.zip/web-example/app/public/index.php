<html>
</body>
<h1 style="text-align: center; font-size: 80pt; margin-top: 100px">HELLO BRITO!</h1>
<?php
phpinfo();
?>
</body>
</html>
